var temp  = " 71°  -  light rain"
var icon ="../icons/10d.png"