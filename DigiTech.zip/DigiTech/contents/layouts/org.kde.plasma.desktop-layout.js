var plasma = getApiVersion(1);

var layout = {
    "desktops": [
        {
            "applets": [
            ],
            "config": {
                "/": {
                    "formfactor": "0",
                    "immutability": "1",
                    "lastScreen": "0",
                    "wallpaperplugin": "org.kde.slideshow"
                },
                "/ConfigDialog": {
                    "DialogHeight": "776",
                    "DialogWidth": "1070"
                },
                "/Configuration": {
                    "PreloadWeight": "0"
                },
                "/General": {
                    "ToolBoxButtonState": "left",
                    "ToolBoxButtonY": "45",
                    "positions": "2,17,desktop:/kodi_crashlog-20171002_154809.log,0,12,desktop:/latte dock.layout.latte,0,13,desktop:/ip.txt,0,10,desktop:/kernl boot options quiet.txt,0,11,desktop:/hs_err_pid3821.log,0,8,desktop:/index.html,0,9,desktop:/recup_dir.2,1,5,desktop:/recup_dir.3,1,6,desktop:/photorec.ses,1,3,desktop:/recup_dir.1,1,4,desktop:/Videos,1,1,desktop:/backup.log,1,2,desktop:/Pictures,0,16,desktop:/speedtest.txt,1,0,desktop:/beach.jpg,1,11,desktop:/beach-rocks-sunset.jpg,1,12,desktop:/private-beach.jpg,1,9,desktop:/tropical-fish.jpg,1,10,desktop:/DRvcTG.jpg,1,7,desktop:/4k-lake.jpg,1,8,desktop:/Downloads2,0,6,desktop:/Hammer-Home,0,7,desktop:/tmp,0,4,desktop:/Docs,0,5,desktop:/Public,0,2,desktop:/Templates,0,3,desktop:/bin,0,0,desktop:/Desktop,0,1,desktop:/mpd.conf,0,14,desktop:/Music,0,15",
                    "showToolbox": "false",
                    "sortMode": "-1"
                },
                "/Wallpaper/General": {
                    "FillMode": "1",
                    "Image": "file:///home/hammer/tropical-fish.jpg",
                    "SlideInterval": "3610",
                    "SlidePaths": "/run/media/hammer/Data/Pictures/4k-water"
                },
                "/Wallpaper/at.lehklu.plasmoid.vallpaper/Settings": {
                    "vdwConfigs": "{\"colorHex\":\"#000000\"\\,\"borderTop\":0\\,\"borderBottom\":0\\,\"borderLeft\":0\\,\"borderRight\":0\\,\"interval\":3600\\,\"fillMode\":2\\,\"geDesaturate\":0\\,\"geFastBlur\":0\\,\"geColorOverlayAlpha\":0\\,\"paths\":[{\"path\":\"file:///run/media/hammer/Data/Pictures/4k-water\"\\,\"type\":\"folder\"}]\\,\"orUrl\":\"\"\\,\"vdNo\":0}"
                },
                "/Wallpaper/at.lehklu.plasmoid.vallpaper2/Settings": {
                    "vallpaper2": "{\"deskNo\":0\\,\"timeslots\":{\"00:00\":{\"slot\":\"00:00\"\\,\"background\":\"#000000\"\\,\"borderTop\":0\\,\"borderBottom\":0\\,\"borderLeft\":0\\,\"borderRight\":0\\,\"fillMode\":2\\,\"desaturate\":0\\,\"blur\":0\\,\"colorize\":0\\,\"colorizeColor\":\"#ffffff\"\\,\"colorizeValue\":\"#00ffffff\"\\,\"interval\":3600\\,\"random\":1\\,\"sources\":[\"file:///run/media/hammer/Data/Pictures/4k-water\"]}}}"
                },
                "/Wallpaper/org.kde.image/General": {
                    "Image": "file:///home/hammer/tropical-fish.jpg"
                },
                "/Wallpaper/org.kde.potd/General": {
                    "FillMode": "2",
                    "Provider": "bing"
                },
                "/Wallpaper/org.kde.slideshow/General": {
                    "Image": "file:///home/hammer/tropical-fish.jpg",
                    "SlideInterval": "7210",
                    "SlidePaths": "/run/media/hammer/Data/Pictures/4k-water",
                    "UncheckedSlides": "file:///run/media/hammer/Data/Pictures/4k-water/200707044111-1773.jpg,file:///run/media/hammer/Data/Pictures/4k-water/200707044516-1729.jpg,file:///run/media/hammer/Data/Pictures/4k-water/200707044958-1781.jpg,file:///run/media/hammer/Data/Pictures/4k-water/426574-svetik_3840x2160.jpg,file:///run/media/hammer/Data/Pictures/4k-water/48ba79ba8d4b9a3a5fb10e0c6acabbff.jpg,file:///run/media/hammer/Data/Pictures/4k-water/BeachParadise8.jpg,file:///run/media/hammer/Data/Pictures/4k-water/gWBsqE9.jpg,file:///run/media/hammer/Data/Pictures/4k-water/pic_01646.jpg,file:///run/media/hammer/Data/Pictures/4k-water/stock-coral-reef-fish-egypt.jpg,file:///run/media/hammer/Data/Pictures/4k-water/Underwater_world_Corals_489134_3840x2400.jpg,file:///run/media/hammer/Data/Pictures/4k-water/V649FJA.jpg,file:///run/media/hammer/Data/Pictures/4k-water/wallhaven-178744.jpg"
                },
                "/Wallpaper/org.kde.video/General": {
                    "Folder": "file:///run/media/hammer/Data/Videos/The Best 4K Aquarium for Relaxation 🐠 Sleep Relax Meditation Music - 2 hours - 4K UHD Screensaver/",
                    "Muted": "true",
                    "Rate": "0.6783783783783783",
                    "Video": "file:///run/media/hammer/Data/Videos/The Best 4K Aquarium for Relaxation 🐠 Sleep Relax Meditation Music - 2 hours - 4K UHD Screensaver/4kAquarium.mp4"
                }
            },
            "wallpaperPlugin": "org.kde.slideshow"
        },
        {
            "applets": [
            ],
            "config": {
                "/": {
                    "formfactor": "0",
                    "immutability": "1",
                    "lastScreen": "1",
                    "wallpaperplugin": "org.kde.slideshow"
                },
                "/ConfigDialog": {
                    "DialogHeight": "684",
                    "DialogWidth": "960"
                },
                "/Configuration": {
                    "PreloadWeight": "0"
                },
                "/Wallpaper/org.kde.color/General": {
                    "Color": "1,0,31"
                },
                "/Wallpaper/org.kde.slideshow/General": {
                    "FillMode": "2",
                    "SlideInterval": "22500",
                    "SlidePaths": "/run/media/hammer/Data/Pictures/4k-water"
                }
            },
            "wallpaperPlugin": "org.kde.slideshow"
        }
    ],
    "panels": [
    ],
    "serializationFormatVersion": "1"
}
;

plasma.loadSerializedLayout(layout);
